﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using pacednl;

namespace pacetranslator
{
    public static class Info
    {
        public static string Version = "pacedntc unimplemented";
    }
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
    public static class Translator
    {
        public static void Translate(string filename)
        {

        }
    }
}
