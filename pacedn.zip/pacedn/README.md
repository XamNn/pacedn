# pacedn
Pace compilation/translation for windows, using Microsoft .NET  
Installing guide here "https://github.com/XamNn/pacedn/wiki/How-to-build-(with-Visual-Studio-2017)"
